import requests
import json
from pathlib import Path

from flask import (
    Blueprint, session, redirect, jsonify, url_for, request
)


import google.oauth2.credentials
import google_auth_oauthlib.flow
import googleapiclient.discovery
from googleapiclient.http import MediaFileUpload
# from apiclient.http import MediaFileUpload

from .. import BASE_PATH

route = Blueprint("drive", __name__, url_prefix='/drive')


CLIENT_SECRETS_FILE = Path().home() / '.resources'/ 'Google'/ 'client_secret__Business Messages - WIFR__178361047091__Drive API - for - autoPosts.json'
TOKEN_PATH = BASE_PATH / '.conf' / 'token_gdrive.json'

SCOPES = ['https://www.googleapis.com/auth/drive.file']
API_SERVICE_NAME = 'drive'
API_VERSION = 'v3'


route.secret_key = 'dev'


with open(CLIENT_SECRETS_FILE) as sf:
    sec_file = json.load(sf)
    CLIENT_ID = sec_file['web']['client_id']
    CLIENT_SECRET = sec_file['web']['client_secret']


@route.route('/')
def index():
  return print_index_table()

@route.route('/test')
def test_api_request():
  if 'credentials' not in session:
    return redirect('authorize')
  
  print(json.dumps(session['credentials'], indent=3))
  # Load credentials from the session.
  credentials = google.oauth2.credentials.Credentials(
      **session['credentials'])

  drive = googleapiclient.discovery.build(
      API_SERVICE_NAME, API_VERSION, credentials=credentials)

  files = drive.files().list().execute()

  # Save credentials back to session in case access token was refreshed.
  # ACTION ITEM: In a production app, you likely want to save these
  #              credentials in a persistent database instead.
  session['credentials'] = credentials_to_dict(credentials)

  return jsonify(**files)

@route.route('/authorize')
def authorize():
  # Create flow instance to manage the OAuth 2.0 Authorization Grant Flow steps.
  flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
      CLIENT_SECRETS_FILE, scopes=SCOPES)

  # The URI created here must exactly match one of the authorized redirect URIs
  # for the OAuth 2.0 client, which you configured in the API Console. If this
  # value doesn't match an authorized URI, you will get a 'redirect_uri_mismatch'
  # error.
  flow.redirect_uri = url_for('oauth2callback', _external=True)

  authorization_url, state = flow.authorization_url(
      # Enable offline access so that you can refresh an access token without
      # re-prompting the user for permission. Recommended for web server apps.
      access_type='offline',
      # Enable incremental authorization. Recommended as a best practice.
      include_granted_scopes='true')

  # Store the state so the callback can verify the auth server response.
  session['state'] = state

  return redirect(authorization_url)

@route.route('/drive/oauth2callback')
def oauth2callback():
  # Specify the state when creating the flow in the callback so that it can
  # verified in the authorization server response.
  state = session['state']

  flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
      CLIENT_SECRETS_FILE, scopes=SCOPES, state=state)
  flow.redirect_uri = url_for('oauth2callback', _external=True)

  # Use the authorization server's response to fetch the OAuth 2.0 tokens.
  authorization_response = request.url
  flow.fetch_token(authorization_response=authorization_response)

  # Store credentials in the session.
  # ACTION ITEM: In a production app, you likely want to save these
  #              credentials in a persistent database instead.
  credentials = flow.credentials
  session['credentials'] = credentials_to_dict(credentials)
  print(json.dumps(credentials_to_dict(credentials), indent=3))

  return redirect(url_for('test_api_request'))

@route.route('/revoke')
def revoke():
  if 'credentials' not in session:
    return ('You need to <a href="/authorize">authorize</a> before ' +
            'testing the code to revoke credentials.')

  credentials = google.oauth2.credentials.Credentials(
    **session['credentials'])

  revoke = requests.post('https://oauth2.googleapis.com/revoke',
      params={'token': credentials.token},
      headers = {'content-type': 'application/x-www-form-urlencoded'})

  status_code = getattr(revoke, 'status_code')
  if status_code == 200:
    return('Credentials successfully revoked.' + print_index_table())
  else:
    return('An error occurred.' + print_index_table())

@route.route('/clear')
def clear_credentials():
  if 'credentials' in session:
    del session['credentials']
  return ('Credentials have been cleared.<br><br>' +
          print_index_table())

def credentials_to_dict(credentials):
  return {'token': credentials.token,
          'refresh_token': credentials.refresh_token,
          'token_uri': credentials.token_uri,
          'client_id': credentials.client_id,
          'client_secret': credentials.client_secret,
          'scopes': credentials.scopes}

def print_index_table():
  return ('<table>' +
          '<tr><td><a href="/test">Test an API request</a></td>' +
          '<td>Submit an API request and see a formatted JSON response. ' +
          '    Go through the authorization flow if there are no stored ' +
          '    credentials for the user.</td></tr>' +
          '<tr><td><a href="/authorize">Test the auth flow directly</a></td>' +
          '<td>Go directly to the authorization flow. If there are stored ' +
          '    credentials, you still might not be prompted to reauthorize ' +
          '    the application.</td></tr>' +
          '<tr><td><a href="/revoke">Revoke current credentials</a></td>' +
          '<td>Revoke the access token associated with the current user ' +
          '    session. After revoking credentials, if you go to the test ' +
          '    page, you should see an <code>invalid_grant</code> error.' +
          '</td></tr>' +
          '<tr><td><a href="/clear">Clear Flask session credentials</a></td>' +
          '<td>Clear the access token currently stored in the user session. ' +
          '    After clearing the token, if you <a href="/test">test the ' +
          '    API request</a> again, you should go back to the auth flow.' +
          '</td></tr></table>')



def get_link(img:Path):
    # Load credentials from the session.
    with open(TOKEN_PATH) as token_f:
        acc_token = json.load(token_f)
    credentials = google.oauth2.credentials.Credentials(
        **acc_token)

    drive = googleapiclient.discovery.build(
        API_SERVICE_NAME, API_VERSION, credentials=credentials)
    
    # Upload File
    if not img.exists() or not img.is_file():
        raise FileNotFoundError("File Not found.")
    file_metadata = {'name': img.name}
    media = MediaFileUpload(img.__str__(),
                            mimetype='image/*',
                            resumable=True)
    file = drive.files().create(body=file_metadata,
        media_body=media, fields="id, webContentLink").execute()
    
    # setting permission
    file_id = file.get('id')
    def callback(request_id, response, exception):
        if exception:   # Handle error
            print(exception)
        else:   # print("Permission Id: %s" % response.get('id'))
            pass

    batch = drive.new_batch_http_request(callback=callback)
    try:
        batch = drive.new_batch_http_request(callback=callback)
    except Exception as e:
        # logger.exception(e)
        print(e)
    user_permission = {
        'type': 'anyone',
        'role': 'reader',
    }
    try:
        batch.add(drive.permissions().create(
            fileId=file.get('id'),
            body=user_permission,
            fields='id',
        ))
    except Exception as e:
        print(e)
    try:
        batch.execute()
    except Exception as e:
        print(e)

    batch.add(drive.permissions().create(
            fileId=file_id,
            body=user_permission,
            fields='id',
    ))
    batch.execute()
    return file.get('webContentLink')



if __name__ == '__main__':
#   # =================== Flask App config ===================
#   # When running locally, disable OAuthlib's HTTPs verification.
#   # ACTION ITEM for developers:
#   #     When running in production *do not* leave this option enabled.
#   os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

#   # Specify a hostname and port that are set as a valid redirect URI
#   # for your API project in the Google API Console.
#   app.run('localhost', 8000, debug=True)
#   # =================== Flask App config ===================

    # =================== Get Link ===================
    img_pth = Path('/home/luffy/Pictures/car.jpg')
    print(get_link(img_pth))
    # =================== Get Link ===================