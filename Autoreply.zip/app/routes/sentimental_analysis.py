
# !pip install -q transformers

# !pip3 install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu113



import random
import json
import numpy
import pandas as pd
import pandasql as ps
from textblob import TextBlob
from transformers import pipeline
sentiment_pipeline = pipeline("sentiment-analysis")



positive=['Thank you for your review,We\'re delighted to hear this response and We will be happy to serve you again.',
          
          'Thank you for your review, Hope to see you again.',
          "Thank you for your review, Looking forward to see you again",        
          "We are grateful that you took the time out to leave us a review.",
          "Thank you so much for sharing your experience with us.",
          "This review made our day!",
          "Thank you for the great review! ",
          "Thank you. We appreciate your feedback and hope to serve you again soon."
          ]




Negative=['Thank you for your feedback,We\'re sorry that we didnt meet your expectations.',

'Thank you for your feedback, We\'re sorry that you were disappointed, if there’s anything else we can do for you, please let us know!',
'Thank you for your feedback,We would like to appologize for the inconvenience casued.'
"Thank you for providing your feedback and letting us know about this issue.",
"We apologize that our service did not satisfy your expectations.",
"Thank you for your review,  we’re sorry to hear you’ve had such a bad experience.",
"Thank you so much for bringing this issue to our attention and please let us apologize for the issue.",
"We would like to apologize for your recent experience. We're sorry to hear you were less than satisfied.",
"We’re sorry to hear of your less-than-satisfactory experience with us and hope you will accept our sincerest apologies."]



five=["Thank you for the 5 star rating.",

"Thank you so much for taking the time to leave us a 5 star rating",

"Thank you so much for taking the time to leave us a 5-star review."]


three_four=["Thank you so much for taking the time to leave us a rating."]

one_two=["Thank you so much for taking the time to leave us a rating."]

BKK_one_two=["Thank you for rating us. We apologize for not meeting your expectations.",
            "Thank you for rating us. We’re sorry to hear that we didn’t meet your expectations.",
            "Thank you for taking the time to share your experience as it’s helping us to improve and ensure a better experience for you next time.",
            "We appreciate you taking the time to share your experience with us, as it enables us to make improvements and guarantee a better experience for   you the following time."]

def Sentiment_analysis(user_id,txt,review):
    whatif_text="You may also try our other Products & Services\n1. Automated Review Response\n2. Google Customize Review\n3. Instagram/FB Management\n4. Developing Website\n\nhttps://whatifretalytics.com/"
    dawat_E_khas="Discover the Taste of Elegance with Daawat_E_Khaas\n\nEmail: daawatekhaas64@gmail.com\nContact: 079-48933777\nMobile: +91 9825380466\nFollow us on Instagram: @Daawat_e_khaas\n\nFor reservations, inquiries, or special requests, feel free to reach out via email, phone, or DM us on Instagram. We're here to make your dining experience truly exceptional."
    blob1=TextBlob(txt[:2000].lower())
    
    k=blob1.sentiment
    if user_id.split("/")[1]== "14849987523243900483":
        if k[0] ==0.0:
            return "Thanks for your Feedback."

            # return "Thanks for your Feedback. \n\n This review is powered by WhatifRetalytics®"
        else:
            ans=sentiment_pipeline(txt[:2000])
            if ans[0]['label']== 'POSITIVE':
                return "Thank you for your review, We will be happy to serve you again."
            else:
                return "We would like to apologize for your recent experience."
        
    elif user_id.split("/")[1]== "2590180202293581244":
         if k[0] ==0.0:

            return " Dear {},\nThanks for your Feedback.\n\n{}".format(review['reviewer']['displayName'],whatif_text)
        
         else:
            
            ans=sentiment_pipeline(txt[:2000])
            if ans[0]['label']== 'POSITIVE':
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(positive)+"\n\n{}".format(whatif_text)
            else:
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(Negative)
        
    elif user_id.split("/")[1]== "18161902787583951373":
         if k[0] ==0.0:

            return " Dear {},\nThanks for your Feedback.\n\n{}".format(review['reviewer']['displayName'],dawat_E_khas)
        
         else:
            
            ans=sentiment_pipeline(txt[:2000])
            if ans[0]['label']== 'POSITIVE':
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(positive)+"\n\n{}".format(dawat_E_khas)
            else:
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(Negative)  
 
    else:
        if k[0] ==0.0:

            return "Dear {},".format(review['reviewer']['displayName'])+"\n"+"Thanks for your Feedback."
        else:
            ans=sentiment_pipeline(txt[:2000])
            if ans[0]['label']== 'POSITIVE':
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(positive)
                # return random.choice(positive)+"\n\nThis review is powered by WhatifRetalytics®"
            else:
                return "Dear {},".format(review['reviewer']['displayName'])+"\n"+random.choice(Negative)
                # return random.choice(Negative)+"\n\nThis review is powered by WhatifRetalytics®"
            
    
BKK_loc=["7147311430605708336","17416635357418562968","7361399563402726660","8266802099776562991"]
def Star_rating(rate,user_id):

    if rate=="FIVE":# Rating is 5⚝
        return random.choice(five)
        # return random.choice(five)+"\n\nThis review is powered by WhatifRetalytics®"
        
                        
    elif rate == "THREE" or rate == "FOUR":         # Rating is 3/4⚝
        return random.choice(three_four)
        # return random.choice(three_four)+"\n\nThis review is powered by WhatifRetalytics®"
#     elif any(x in user_id for x in BKK_loc):
    
    else:
        user_id=user_id.split("/")[1]
        if  any(x in user_id for x in BKK_loc):
            return random.choice(BKK_one_two)
            # +"\n\nThis review is powered by WhatifRetalytics®"
        else:
            return random.choice(BKK_one_two)
            # +"\n\nThis review is powered by WhatifRetalytics®"

# user_id="113460850118416824015/2590180202293581244"
# user_id="109670058769108403352/14849987523243900483"


def get_data(user_id):
    Id=user_id.split('/')[1]
    ####################
    import json
    f = open('/home/server/.dev/AutoReviewApp/.res/autoreview_store.json')
    data = json.load(f)
    ########################
    for i in data:
        k=i['loc_id']
    
        if user_id.split('/')[1]==str(k):
            store=i['name']
    #########################
    df=pd.read_excel("/home/server/.dev/AutoReviewApp/app/Exclusion_words.xlsm")
    
    DF=dict(df.to_numpy())
    for i ,j in DF.items():
        if store == i:
            Exclusion_Words_=j.split(',')
#             print(j)
    Exclusion_Words_List=Exclusion_Words_
    return Exclusion_Words_List



def Autoreply_review(user_id, comment, review:dict):
    Exclusion_Words_=get_data(user_id)

    if any(x.lower() in comment.lower() for x in Exclusion_Words_):
        return "Sorry you have mistakenly put comment here"
    else:
        return Sentiment_analysis(user_id,comment,review)
    




# print(Autoreply_review("113460850118416824015/2590180202293581244","MAYURA JWELLERS IS VERY RELIABLE AND DEPENDABLE CENTER. I HAVE BEEN IN REGULAR TOUCH AND DEALINGS FOR LAST 18 YEARS. VERY CUSTOMER FRIENDLY. WISH THEM ALL THE BEST."))


