import os
import json
import datetime
from pathlib import Path
import random
from shutil import move as shutil_move
from typing import List
from .. import sentimental_analysis
import csv

from flask import Blueprint, jsonify, current_app, redirect, session, url_for, request

import google.oauth2.credentials
import google_auth_oauthlib.flow
import googleapiclient.discovery

import requests

from .. import BASE_PATH

route = Blueprint('gmb', __name__, url_prefix='/gmb')


SECRETS_FILE_PATH = Path().home() / '.resources'/ 'Google'

CLIENT_SECRETS_FILE = SECRETS_FILE_PATH / 'client_secret__Business Messages - WIFR__178361047091__Drive API - for - autoPosts.json'
# SCOPES = 'https://www.googleapis.com/auth/business.manage'                   # Read From client_secret.json
SCOPES = [
    'https://www.googleapis.com/auth/business.manage',
    'https://www.googleapis.com/auth/businesscommunications'
]

API_SERVICE_NAME = "mybusinessbusinessinformation"      # https://developers.google.com/my-business/reference/businessinformation/rest#service:-mybusinessbusinessinformation.googleapis.com
API_VERSION = 'v1'


ARCHIVE_PATH = Path().home() / '.Post_Archive'


try:os.makedirs(str(ARCHIVE_PATH))
except Exception as e : pass


class TokenCode:
    """ Getting tokenCode to """

    def __init__(self):
        self.token_path = BASE_PATH/ '.conf'/ 'ref_token.json'
    
    def get_access_token(self):
        """ getting access_token """

        with open (self.token_path) as token_f:
            acc_token = json.load(token_f)
            if not acc_token.get("new_token_time") or self.is_access_token_expired(acc_token.get("new_token_time")):
                return self.get_new_access_token(acc_token.get("refresh_token"))
            else:
                return acc_token.get("access_token")

    def get_new_access_token(self, refresh_token):
        """ Getting New **access_token** Using **refresh_token** """
        with open(CLIENT_SECRETS_FILE) as f:
            client_sec_file =  json.load(f)
        url = "https://oauth2.googleapis.com/token"             # Read From client_secret.json
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = {
            "client_id": client_sec_file['web'].get("client_id"),              # Read From client_secret.json
            "client_secret": client_sec_file['web'].get("client_secret"),      # Read From client_secret.json
            "refresh_token": refresh_token,
            "grant_type": "refresh_token"
        }
        req = requests.post(url, headers=headers, data=data)

        print("\n\n\n\n\n=======================")
        print(req.json())
        print(data)
        print(headers)
        print(client_sec_file, CLIENT_SECRETS_FILE)
        print("=======================\n\n\n\n\n")

        new_token_time = datetime.datetime.now() + datetime.timedelta(seconds=int(req.json().get("expires_in"))-99 )
        self.update_access_token(req.json().get("access_token"), new_token_time)
        return req.json().get("access_token")

    def is_access_token_expired(self, token_exp_time):
        """ Checking is access_token expired or not """
        if datetime.datetime.strptime(token_exp_time, "%Y-%m-%d %H:%M:%S.%f") > datetime.datetime.now():
            # Token Not Is Expire
            return False 
        else:   # Token Is Expire
            return True

    def update_access_token(self, access_token, new_token_time):
        """ Updating the new access_token and  new_token_time """
        with open (self.token_path) as token_f:
            acc_token = json.load(token_f)
            acc_token['access_token'] = access_token
            acc_token['new_token_time'] = str(new_token_time)
            json.dump(acc_token, open(self.token_path, "w"), indent=4)


class AccLocId(TokenCode):
    """ Getting token And id i.e account_id, location_id, post_id, etc. """
    def __init__(self, acc_id:int=None, loc_id:int=None):
        super(AccLocId, self).__init__()
        self.acc_id = str(acc_id)
        self.loc_id = str(loc_id)
        self.acc_url_ = "https://mybusinessaccountmanagement.googleapis.com/v1/"
        self.loc_url_ = "https://mybusinessbusinessinformation.googleapis.com/v1/"
    
    def get_store_labels(self):
        """ 
        Getting **storeCode** and **labels** for getting acc_id and loc_id from GMB 

        # calling the get_loc_id() method from here and set the scheduler in Do_Action class
        """

    def get_acc_id(self):
        """ Getting Account Id """
        url=self.acc_url_+"accounts"

        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        req = requests.get(url, headers=headers)

        return req.json()
    
    def get_acc(self, page_size:int=20, page_token:str=None, filter:str=None, _accs:dict={}):
        page_size = page_size if page_size >= 1 and page_size <= 20 else 20
        page_token = f"&pageToken={page_token}" if page_token else ""
        url = self.acc_url_+f"accounts?pageSize={page_size}{page_token}"
        
        headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
        resp = requests.get(url, headers=headers)
        

        if resp.status_code == 200:
            acc_data = resp.json()
            try:
                _accs['accounts'].extend(acc_data['accounts'])
            except Exception as e:
                _accs = acc_data
            
            if acc_data.get('nextPageToken'):
                return self.get_acc(
                        page_token=acc_data.get('nextPageToken'),
                        _accs = _accs
                    )
            else:
                # Returning all locations of this group
                return _accs

        
    
    def get_loc_id(self, locId, storeCode=None, labels=None):
        """ Geting Location Id 
        
        check location id is present or not 
        if present return image folder name     FOLDER_NAME_FORMATE : <loc_id>___<loc_name>
        
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }
        """
        locs = self.get_locations()
        is_location_found = False
        try:
            for i in locs.get("locations"):
                if i.get('name').split('/')[-1] == locId:
                    # print(json.dumps(i))
                    client_folder_name = f"{i.get('name').split('/')[-1]}___{i.get('title')}"
                    is_location_found = {'locName':i.get("name"), 'clientFolderName':client_folder_name}
                    break
            if is_location_found:
                # print(f"is_location_found : {is_location_found}")
                return is_location_found
            else:           # No Loction Found
                return False
        except Exception as e:      # No Loction Found
            # print(e)
            return False

    def get_loc_by_store_code(self, storeCode):
        """ 
        Getting the location with help of Store Code or loc_id
        
        :param storeCode: Store Code Of Store
        :type storeCode: str
        """

        loc_list = self.get_locations()
        
        if storeCode:
            for loc in loc_list.get("locations"):
                if loc.get('storeCode'):
                    if storeCode == loc.get('storeCode'):
                        return loc
            return {
                "error": {
                    "code" : 400,
                    "status" : "INVALID_ARGUMENT",
                    "message" : "Invalid location argument."
                }
            }
        else:
            return {
                "error": {
                    "code" : 404,
                    "status" : "NOT_FOUND",
                    "message" : "Store code not found"
                }
            }

    def get_loc_by_name(self, name):
        """ Geting Location Id 
        
        check location id is present or not 
        if present return image folder name     FOLDER_NAME_FORMATE : <loc_id>___<loc_name> 
        
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }
        """
        
        locs = self.get_locations()
        is_location_found = False
        try:
            for i in locs.get("locations"):
                if i.get('name').split('/')[-1] == name:
                    # print(json.dumps(i))
                    client_folder_name = f"{i.get('name').split('/')[-1]}___{i.get('title')}"
                    is_location_found = {'locName':i.get("name"), 'clientFolderName':client_folder_name}
                    break
            if is_location_found:
                print(f"is_location_found : {is_location_found}")
                return is_location_found
            else:           # No Loction Found
                return False
        except Exception as e:      # No Loction Found
            print(e)
            return False

    def get_locations(self, acc_id=None):
        """ Geting Location Id """
        
        if acc_id:
            acc_urls = (f"accounts/{acc_id}",)
        else:
            acc_urls = [acc.get("name") for acc in self.get_acc().get("accounts")]
        all_locs = {'locations': []}
        for _acc in acc_urls:
            try:
                _tmp_loc = self.get_loc(_acc.split('/')[-1], pageSize=100)['locations'] if self.get_loc(_acc.split('/')[-1], pageSize=100)['locations'] else list()
                all_locs['locations'] +=  _tmp_loc
            except Exception as e:
                print(f"Adding Location of Account id: {_acc}")
        return all_locs

    def get_loc(self, acc_id:str, pageSize:int=25, pageToken:str=None, filter:str=None, orderBy:str=None, readMask:str=None, _loc_list:list=[]):
        page_size = pageSize if pageSize >= 1 and pageSize <= 100 else 25
        page_token = f"&pageToken={pageToken}" if pageToken else ""
        url = self.loc_url_+f"accounts/{acc_id}/locations?pageSize={page_size}{page_token}&readMask=title,name,storeCode"
        
        headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
        resp = requests.get(url, headers=headers)
        
        if _loc_list:
            _locs = {'locations': _loc_list}
        else:
            _locs = {'locations': list()}
        
        if resp.status_code == 200:
            loc_data = resp.json()
            
            if loc_data:
                for j in loc_data['locations']:
                    j['name'] =  f"accounts/{acc_id}/"+ j['name']
                    _locs['locations'].append(j)
            if loc_data.get('nextPageToken'):
                return self.get_loc(
                        acc_id,
                        pageToken=loc_data.get('nextPageToken'),
                        _loc_list = _locs['locations']
                    )
            else:
                # Returning all locations of this group
                return _locs


class Posts(AccLocId):
    """All the Posts Features"""
    def __init__(self, acc_id:int, loc_id:int):
        AccLocId.__init__(self, acc_id=acc_id, loc_id=loc_id)
        self.post_url_ = 'https://mybusiness.googleapis.com/v4/'

    def get_post(self, post_id:int):
        """ Get a Post info """
        url = self.post_url_ + f"accounts/{self.acc_id}/locations/{self.loc_id}/localPosts/{post_id}"
        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        req = requests.get(url, headers=headers)
        return req.json()
        
    def get_posts(self):
        """ Get all the Posts done previously """
        url = self.post_url_ + f"accounts/{self.acc_id}/locations/{self.loc_id}/localPosts"
        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        req = requests.get(url, headers=headers)
        return req.json()
    
    def create_event_post(self, data, storeCode, labels=None):
        """ Creates a Event Post """
        url = self.post_url_ + str(self.get_loc_id(storeCode, labels))+"/localPosts"
        c_dt = datetime.datetime.now() + datetime.timedelta(minutes=2)
        
        # Formating Data in 
        frmt_data = {} 
        frmt_data["languageCode"] = "en-US"
        frmt_data["summary"] = data.get("summary")
        frmt_data_event_schedule_startDate = {
            "year" : int(data.get("startDate (year)")),
            "month" : int(data.get("startDate (month)")),
            "day" : int(data.get("startDate (day)"))}
        frmt_data_event_schedule_startTime = {
            "hours": int(data.get("startTime (hours)") if data.get("startTime (hours)") else c_dt.hour),
            "minutes": int(data.get("startTime (minute)") if data.get("startTime (minute)") else c_dt.minute),
            "seconds": int(data.get("startTime (sec)") if data.get("startTime (sec)") else 0),
            "nanos": int(data.get("startTime (nanoSec)") if data.get("startTime (nanoSec)") else 0)}
        frmt_data_event_schedule_endDate = {
            "year" : int(data.get("endDate (year)")),
            "month" : int(data.get("endDate (month)")),
            "day" : int(data.get("endDate (day)"))}
        frmt_data_event_schedule_endTime = {
            "hours": int(data.get("endTime (hours)") if data.get("endTime (hours)") else 23),
            "minutes": int(data.get("endTime (minute)") if data.get("endTime (minute)") else 59),
            "seconds": int(data.get("endTime (sec)") if data.get("endTime (sec)") else 0),
            "nanos": int(data.get("endTime (nanoSec)") if data.get("endTime (nanoSec)") else 0)}
        frmt_data_event_schedule = {
            "startDate" : frmt_data_event_schedule_startDate,
            "startTime" : frmt_data_event_schedule_startTime,
            "endDate" : frmt_data_event_schedule_endDate,
            "endTime" : frmt_data_event_schedule_endTime}
        frmt_data["event"] = {
            "title" : data.get("title"),
            "schedule" : frmt_data_event_schedule}
        frmt_data["media"] = [
            {
                "mediaFormat" : "PHOTO",
                "sourceUrl" : create_url_if_local(i.replace(" ","").replace("\t", ""))
            }for i in data.get("media PHOTO(url/path)").split(',') if i != ""] \
                + [{
                    "mediaFormat" : "VIDEO",
                    "sourceUrl" : create_url_if_local(i.replace(" ","").replace("\t", ""))
                }for i in data.get("media VIDEO(url/path)").split(',') if i != ""]
        
        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        headers['Content-Length'] = str(len(json.dumps(frmt_data)))
        req = requests.post(url, headers=headers, data=json.dumps(frmt_data))
        # print(json.dumps(req.json(), indent=4))
        return req

    def create_action_post(self, imgs:List[str], summary:str)-> dict:
        """ Creates a Action Post (UI/UX -> What's New) """
        url = self.post_url_ + f"accounts/{self.acc_id}/locations/{self.loc_id}/localPosts"
        for i in imgs:
            if i[:4] == 'http':
                pass
            else:
                del i
        if not imgs:
            return {"error": "Image Link Not Fot Found"}
        # Formating Data in 
        frmt_data = {} 
        frmt_data["languageCode"] = "en-US"
        frmt_data["summary"] = summary
        frmt_data["callToAction"] = {
            "actionType" : 'CALL',
            "url" : None}
        frmt_data["media"] = [
            {
                "mediaFormat" : "PHOTO",
                "sourceUrl" : img
            }for img in imgs]
        frmt_data['topic_type'] = "STANDARD"

        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        headers['Content-Length'] = str(len(json.dumps(frmt_data)))
        # upload_media(str(loc.get('locName')), headers, frmt_data['media'])
        resp = requests.post(url, headers=headers, data=json.dumps(frmt_data))
        return resp.json()
        # try:
        #     if req.status_code == 200 :
        #         # delete the image which are posted
        #         file_name = f"{datetime.datetime.now().strftime('%y_%m_%d %H_%M_%S_%f')}{Path(i).suffix}"
        #         arch_folder_path = ARCHIVE_PATH / req.url.split('/')[-2]
        #         # Creatimg location Archive folder 
        #         try:os.makedirs(str(arch_folder_path))
        #         except Exception as e : pass

        #         try: 
        #             for i in imgList:
        #                 shutil_move(i, str(ARCHIVE_PATH / arch_folder_path / file_name))
        #                 # os.remove(i)
        #         except FileNotFoundError:
        #             pass
        #         except Exception as e:
        #             print(e)
        #         try:
        #             # Writing Summary in file
        #             summary_file_name = Path(file_name).stem + ".txt"
        #             summary_file_path = arch_folder_path/summary_file_name
        #             write_summary(summary_file_path, summary)
        #         except Exception as e:
        #             print("Write Summary error: ", e)
        #         return req
        #     else:
        #         print(json.dumps(req.json(), indent=3))
        #         # delete the image which are posted
        #         file_name = f"{datetime.datetime.now().strftime('%y_%m_%d %H_%M_%S_%f')}{Path(i).suffix}"
        #         arch_folder_path = ARCHIVE_PATH / req.url.split('/')[-2] / '.error'
                
        #         # Creatimg location Archive folder 
        #         try:os.makedirs(str(arch_folder_path))
        #         except Exception as e : pass

                
                

        #         try: 
        #             for i in imgList:
        #                 shutil_move(i, str(ARCHIVE_PATH / arch_folder_path / file_name))
        #                 # os.remove(i)
        #         except FileNotFoundError:
        #             pass
        #         except Exception as e:
        #             print(e)
        #         try:
        #             # Writing Summary in file
        #             summary_file_name = Path(file_name).stem + ".txt"
        #             summary_file_path = arch_folder_path/summary_file_name
        #             write_summary(summary_file_path, summary)
        #         except Exception as e:
        #             print("Write Summary error: ", e)
        #         return req
        # except Exception as e:
        #     print('\n\n\n\n\n', '*'*70)
        #     print(e)
        #     # print(req)
        #     print('*'*70, '\n\n\n\n\n')
            
    def create_offer_post(self):
        """ Creates a Offer Post """
        return
    
    def edit_post(self):
        """ Edits the older Post """
        return

    def delete_post(self):
        """ Delete The Posts """
        return

    
def upload_media(loc, header, data):
    url = 'https://mybusiness.googleapis.com/v4/'+loc+"/media"
    # {
    # "mediaFormat": "PHOTO",
    # "locationAssociation": {
    #     "category": "COVER"
    # },
    # "sourceUrl": "",
    # }
    for i in data:
        frmt_data = {
            "mediaFormat": "PHOTO",
            "locationAssociation": {
                "category": "ADDITIONAL"
            },
            "sourceUrl": i.get('sourceUrl'),
        }
        try:
            header['Content-Length'] = str(len(json.dumps(frmt_data)))
            req = requests.post(url, headers=header, data=json.dumps(frmt_data))
            # print('*'*50)
            # print(url,"\n",  header,"\n", json.dumps(frmt_data), "\n\n\n")
            # print(req.text)
            # print(req.json)
            # print('*'*50)
        except Exception as e:
            print('\n\n\n\n\n','*'*50)
            print("Media Upload Error GMB", e)
            print(url,"\n", json.dumps(frmt_data), "\n\n\n")
            print('*'*50, '\n\n\n\n\n')

def write_summary(summary_file_name, summary):
    try:
        with open(str(ARCHIVE_PATH/summary_file_name), 'w') as _file:
            _file.write(summary)
    except Exception as e:
        print('Faild to write a summary file')
        return False
    else: return True


class Reviews(AccLocId):
    """All the Posts Features"""
    def __init__(self, acc_id:int, loc_id:int):
        AccLocId.__init__(self, acc_id=acc_id, loc_id=loc_id)
        self.review_url_ = 'https://mybusiness.googleapis.com/v4/'
    
    def get_reviews(self, page_size:int=50, page_token:str=None, filter:str=None, _reviews:dict={}, req_all=True):
        page_size = page_size if page_size >= 1 and page_size <= 50 else 50
        page_token = f"&pageToken={page_token}" if page_token else ""
        
        url = self.review_url_ + f"accounts/{self.acc_id}/locations/{self.loc_id}/reviews?pageSize={page_size}{page_token}"
        
        headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
        resp = requests.get(url, headers=headers)
        

        if resp.status_code == 200 and req_all:
            review_data = resp.json()
            try:
                _reviews['reviews'].extend(review_data['reviews'])
                if _reviews.get('nextPageToken'):
                    del _reviews['nextPageToken']
            except Exception as e:
                _reviews = review_data
            if review_data.get('nextPageToken'):
                return self.get_reviews(
                        page_token=review_data.get('nextPageToken'),
                        _reviews = _reviews
                    )
            else:
                # Returning all locations of this group
                return _reviews
        else:
            return resp.json()

    def put_review(self, review_id, review_comment):
        
        """ Creates a Action Post (UI/UX -> What's New) """
        url = self.review_url_ + f"accounts/{self.acc_id}/locations/{self.loc_id}/reviews/{review_id}/reply"
        
        frmt_data = {
            "comment": review_comment
        }

        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        headers['Content-Length'] = str(len(json.dumps(frmt_data)))
        resp = requests.put(url, data=json.dumps(frmt_data), headers=headers)
        print(resp.status_code, resp.text)
        return resp.json()



@route.route('/loc/accs')
def accs():
    return jsonify(AccLocId().get_acc())


@route.route('/loc/locs')
def locs():
    return jsonify(AccLocId().get_locations())

def get_stores():
    try:
        with open(current_app.config['AUTOREVIEW_STORE_JSON']) as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []


@route.route('/review_all/<acc>/<loc>')
def rew_tmp(acc: int, loc: int):
    """
    Replay all the Reviews of the locations
    """
    a = Reviews(acc_id=acc, loc_id=loc).get_reviews(req_all=True)
    return a


@route.route('/review')
def rew():
    """
    Replay thee the reviews of the Json File
    """
    for store in get_stores():
        print("\n\n\n", "==="*20, store, "==="*20, "\n\n\n")
        try:
            revs = Reviews(acc_id=store.get('acc_id'), loc_id=store.get('loc_id')).get_reviews(req_all=False)
        except KeyError:
            return "invalid account or location id."
        
        for i in revs['reviews']:
            try:    # Checking is reply is already updated or not
                i['reviewReply']
            except KeyError:
                print("\treplying a review")
                try:        # if 'comment' in i:
                    txt=i['comment']
                    print("\t\tComment: \t", txt)
                    # try:
                    reply_comment = sentimental_analysis.Autoreply_review("/".join([str(store.get('acc_id')), str(store.get('loc_id'))]), txt, i)
                    Reviews(acc_id=store.get('acc_id'), loc_id=store.get('loc_id')).put_review(i["reviewId"], reply_comment)
                    # except Exception as e:
                    #     pass

                    print("\t\tAns: \t", reply_comment,"\n")
                except KeyError: 
                    # Function call for rating 

                    rate=i['starRating']
                    acc_loc = "/".join([str(store.get('acc_id')), str(store.get('loc_id'))])
                    reply_comment = sentimental_analysis.Star_rating(rate,acc_loc)


                    # print("\tRating: \t", rate)
                    # if rate=="FIVE":        # Rating is 5⚝
                    #     reply_comment = random.choice(sentimental_analysis.five)
                    #     print("\t\t 5⚝ Ans: \t", reply_comment,"\n")
                        
                    # elif rate == "THREE" or rate == "FOUR":         # Rating is 3/4⚝
                    #     reply_comment = random.choice(sentimental_analysis.three_four)
                    #     print("\t\t 3/4⚝ Ans: \t", reply_comment,"\n")

                    # else:       # rating is 1/2⚝
                    #     reply_comment = random.choice(sentimental_analysis.one_two)

                    #     print("\t\t 1/2⚝Ans: \t", reply_comment,"\n")
                    Reviews(acc_id=store.get('acc_id'), loc_id=store.get('loc_id')).put_review(i["reviewId"], reply_comment)

    return {"status": "OK"}


@route.route('/review/update/<acc>/<loc>/<rev_id>/<comment>')
def set_rev(acc, loc, rev_id, comment):
    return Reviews(acc_id=acc, loc_id=loc).put_review(rev_id, comment)


# Get access Token from User

@route.route('/init')
def index():
  return print_index_table()

@route.route('/test')
def test_api_request():
  if 'credentials' not in session:
    return redirect('authorize')
  
  print(json.dumps(session['credentials'], indent=3))
  # Load credentials from the session.
  credentials = google.oauth2.credentials.Credentials(
      **session['credentials'])

#   drive = googleapiclient.discovery.build(
#       API_SERVICE_NAME, API_VERSION, credentials=credentials)

  

  # Save credentials back to session in case access token was refreshed.
  # ACTION ITEM: In a production app, you likely want to save these
  #              credentials in a persistent database instead.
  credentials_dict = credentials_to_dict(credentials)
  print(credentials_dict)
  ref_token_path = BASE_PATH/ '.conf'/ 'ref_token.json'
  json.dump(credentials_dict, open(ref_token_path, 'w'), indent=4)

  return jsonify(credentials_dict)


@route.route('/authorize')
def authorize():
  # Create flow instance to manage the OAuth 2.0 Authorization Grant Flow steps.
  flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
      CLIENT_SECRETS_FILE, scopes=SCOPES)

  # The URI created here must exactly match one of the authorized redirect URIs
  # for the OAuth 2.0 client, which you configured in the API Console. If this
  # value doesn't match an authorized URI, you will get a 'redirect_uri_mismatch'
  # error.
  flow.redirect_uri = url_for('gmb.oauth2callback', _external=True)

  authorization_url, state = flow.authorization_url(
      # Enable offline access so that you can refresh an access token without
      # re-prompting the user for permission. Recommended for web server apps.
      access_type='offline',
      # Enable incremental authorization. Recommended as a best practice.
      include_granted_scopes='true')

  # Store the state so the callback can verify the auth server response.
  session['state'] = state

  return redirect(authorization_url)

@route.route('/oauth2callback')
def oauth2callback():
  # Specify the state when creating the flow in the callback so that it can
  # verified in the authorization server response.
  state = session['state']

  flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
      CLIENT_SECRETS_FILE, scopes=SCOPES, state=state)
  flow.redirect_uri = url_for('gmb.oauth2callback', _external=True)

  # Use the authorization server's response to fetch the OAuth 2.0 tokens.
  authorization_response = request.url
  os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
  flow.fetch_token(authorization_response=authorization_response)

  # Store credentials in the session.
  # ACTION ITEM: In a production app, you likely want to save these
  #              credentials in a persistent database instead.
  credentials = flow.credentials
  session['credentials'] = credentials_to_dict(credentials)
  print(json.dumps(credentials_to_dict(credentials), indent=3))

  return redirect(url_for('gmb.test_api_request'))

@route.route('/revoke')
def revoke():
  if 'credentials' not in session:
    return ('You need to <a href="/authorize">authorize</a> before ' +
            'testing the code to revoke credentials.')

  credentials = google.oauth2.credentials.Credentials(
    **session['credentials'])

  revoke = requests.post('https://oauth2.googleapis.com/revoke',
      params={'token': credentials.token},
      headers = {'content-type': 'application/x-www-form-urlencoded'})

  status_code = getattr(revoke, 'status_code')
  if status_code == 200:
    return('Credentials successfully revoked.' + print_index_table())
  else:
    return('An error occurred.' + print_index_table())

@route.route('/clear')
def clear_credentials():
  if 'credentials' in session:
    del session['credentials']
  return ('Credentials have been cleared.<br><br>' +
          print_index_table())


def credentials_to_dict(credentials):
  return {'token': credentials.token,
          'refresh_token': credentials.refresh_token,
          'token_uri': credentials.token_uri,
          'client_id': credentials.client_id,
          'client_secret': credentials.client_secret,
          'scopes': credentials.scopes}

def print_index_table():
  return ('<table>' +
          '<tr><td><a href="./test">Test an API request</a></td>' +
          '<td>Submit an API request and see a formatted JSON response. ' +
          '    Go through the authorization flow if there are no stored ' +
          '    credentials for the user.</td></tr>' +
          '<tr><td><a href="./authorize">Test the auth flow directly</a></td>' +
          '<td>Go directly to the authorization flow. If there are stored ' +
          '    credentials, you still might not be prompted to reauthorize ' +
          '    the application.</td></tr>' +
          '<!-- <tr><td><a href="./revoke">Revoke current credentials</a></td>' +
          '<td>Revoke the access token associated with the current user ' +
          '    session. After revoking credentials, if you go to the test ' +
          '    page, you should see an <code>invalid_grant</code> error.' +
          '</td></tr>' +
          '<tr><td><a href="./clear">Clear Flask session credentials</a></td>' +
          '<td>Clear the access token currently stored in the user session. ' +
          '    After clearing the token, if you <a href="/test">test the ' +
          '    API request</a> again, you should go back to the auth flow.' +
          '</td></tr> --></table>')