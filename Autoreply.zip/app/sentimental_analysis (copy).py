
# !pip install -q transformers

# !pip3 install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu113



import random
import json
import numpy
import pandas as pd
import pandasql as ps
from textblob import TextBlob
from transformers import pipeline
sentiment_pipeline = pipeline("sentiment-analysis")



positive=['Thank you for your review,We\'re delighted to hear this response and We will be happy to serve you again.',
          
'Thank you for your review, Hope to see you again.',
          "Thank you for your review, Looking forward to see you again",
                   
          "We are grateful that you took the time out to leave us a review.",
          "Thanks so much for sharing your experience with us.",
        "This review made our day!",
          "Thank you for the great review! ",
          "Thank you. We appreciate your feedback and hope to serve you again soon."
          ]




Negative=['Thank you for your feedback,We\'re sorry that we didnt meet your expectations.',

'Thank you for your feedback, We\'re sorry that you were disappointed, if there’s anything else we can do for you, please let us know!',

'Thank you for your feedback,We would like to appologize for the inconvenience casued.'
"Thank you for providing your feedback and letting us know about this issue.",
"We apologize that our service did not satisfy your expectations.",
"Thank you for your review,  we’re sorry to hear you’ve had such a bad experience.",
"Thanks so much for bringing this issue to our attention and please let me apologize for the issue.",
"We would like to apologize for your recent experience. We're sorry to hear you were less than satisfied.",
"We’re sorry to hear of your less-than-satisfactory experience with us and hope you will accept our sincerest apologies."]



five=["Thank you for the 5 star rating.",

"Thank you so much for taking the time to leave us a 5 star rating",

"Thank you so much for taking the time to leave us a 5-star review."]


three_four=["Thank you so much for taking the time to leave us a rating."]

one_two=["Thank you so much for taking the time to leave us a rating."]



def Sentiment_analysis(user_id,txt):
    
    blob1=TextBlob(txt.lower())
    
    k=blob1.sentiment
    if user_id.split("/")[1]== "14849987523243900483":
        if k[0] ==0.0:

            return "Thanks for your Feedback."
        else:
            ans=sentiment_pipeline(txt)
            if ans[0]['label']== 'POSITIVE':
                return "Thank you for your review, We will be happy to serve you again."
            else:
                return "We would like to apologize for your recent experience."
        
    
    else:
        if k[0] ==0.0:

            return "Thanks for your Feedback."
        else:
            ans=sentiment_pipeline(txt)
            if ans[0]['label']== 'POSITIVE':
                return random.choice(positive)
            else:
                return random.choice(Negative)
            
    


# user_id="113460850118416824015/2590180202293581244"
# user_id="109670058769108403352/14849987523243900483"


def get_data(user_id):
    Id=user_id.split('/')[1]
    ####################
    import json
    f = open('/home/server/.dev/AutoReviewApp/.res/autoreview_store.json')
    data = json.load(f)
    ########################
    for i in data:
        k=i['loc_id']
    
        if user_id.split('/')[1]==str(k):
            store=i['name']
    #########################
    df=pd.read_excel("/home/server/.dev/AutoReviewApp/app/Exclusion_words.xlsm")
    
    DF=dict(df.to_numpy())
    for i ,j in DF.items():
        if store == i:
            Exclusion_Words_=j.split(',')
#             print(j)
    Exclusion_Words_List=Exclusion_Words_
    return Exclusion_Words_List



def Autoreply_review(user_id,review):
    Exclusion_Words_=get_data(user_id)

    if any(x.lower() in review.lower() for x in Exclusion_Words_):
        return "Sorry you have mistakenly put review here"
    else:
        return Sentiment_analysis(user_id,review)
    




# print(Autoreply_review("113460850118416824015/2590180202293581244","MAYURA JWELLERS IS VERY RELIABLE AND DEPENDABLE CENTER. I HAVE BEEN IN REGULAR TOUCH AND DEALINGS FOR LAST 18 YEARS. VERY CUSTOMER FRIENDLY. WISH THEM ALL THE BEST."))


