$(document).ready(() => {
    // To enable Tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))



    /**
     * enable textarea on double click
     */
    $('textarea.readonly').dblclick((e) => {
        // console.log(e.currentTarget);
        e.currentTarget.classList.remove("readonly")
        e.currentTarget.removeAttribute('readonly')
    })
    /**
     * disabled the textarea when it get blur 
     */
    $('textarea.default_cap').blur((e) => {
        // console.log(e.currentTarget);
        e.currentTarget.setAttribute('readonly', 'readonly')
        e.currentTarget.classList.add("readonly")
    })
    /**
     *  add Class ".modified_cap" in classList to update only modified fields
     */
    $("textarea.caption_field").change((e) => {
        if (!e.currentTarget.classList.contains('modified_cap')) {
            e.currentTarget.classList.add("modified_cap")
        }
    })

    /**
     * Saving all the modified captions
     */
    $('#save_captions').click((e) => {
        e.currentTarget.classList.add('disabled')
        caption_folds = document.querySelectorAll('.caption_lists .caption_fold_')

        let captions = []
        for (let i = 0; i < caption_folds.length; i++) {
            let caption_imgs = caption_folds[i].querySelectorAll('.caption_img_')

            fold_id = caption_folds[i].querySelector('.default_cap').dataset.id

            let default_caption = ""
            if (caption_folds[i].querySelector('.default_cap.modified_cap')) {
                default_caption = caption_folds[i].querySelector('.default_cap.modified_cap').value
                console.log(`fold_id : ${fold_id}`)
            }

            let fold_captions = []
            for (let j = 0; j < caption_imgs.length; j++) {
                if (caption_imgs[j].querySelector('.image_caption.modified_cap')) {
                    let img_id = caption_imgs[j].querySelector('.image_caption.modified_cap').dataset.id
                    let img_path = caption_imgs[j].querySelector('.main_img_').getAttribute('src')
                    let image_caption = caption_imgs[j].querySelector('.image_caption.modified_cap').value
                    fold_captions.push({ id: img_id, path: img_path, caption: image_caption })
                }
            }

            if (caption_folds[i].querySelector('.default_cap.modified_cap')) {
                captions.push({ imgs: fold_captions, default_caption: default_caption, folder: fold_id })
            } else {
                captions.push({ imgs: fold_captions, folder: fold_id })
            }

        }

        console.log(captions)
        // Sending caption to server
        $.post("", { 'captions': JSON.stringify(captions) })
            .done((data) => {
                console.log(data)
                alert(data)
                e.currentTarget.classList.remove('disabled')
            })
            .fail((jqXHR) => {
                console.log(jqXHR)
                alert("Faild to save captions")
                e.currentTarget.classList.remove('disabled')
            })
    })

    /**
     * Posting this store image 
     */
    $('.post_images_cur_fol').click((e) => {      // Post this store images
        e.currentTarget.classList.add('disabled')
        e.currentTarget.dataset.id

        let ele = $(`#foldId_${e.currentTarget.dataset.id} .post_allowed textarea.image_caption:nth-child(1)`)[0]
        if (ele) {

            let id = ele.dataset.id

            $.post("/post", { id: id })
                .done((data) => {
                    // console.log(data)
                    e.currentTarget.classList.remove('disabled')
                    e.currentTarget.parentElement.querySelector('.Completed_post_image_count').innerText = data.posts
                    ele.parentElement.parentElement.remove()
                })
                .fail((jqXHR) => {
                    console.log(jqXHR)
                    e.currentTarget.classList.remove('disabled')

                    let ele = e.currentTarget.parentElement

                    let error_count = ele.querySelector(".Failed_post_image_count")

                    // Display error message btn
                    error_count.parentElement.classList.remove("d-none")

                    // // Updating Error Count
                    error_count.innerText = parseInt(error_count.innerText) + 1
                    // adding error message in dropdown table

                    let status_code = jqXHR.responseJSON.error.code
                    let msg = jqXHR.responseJSON.error.message

                    ele.querySelector(".Failed_post_image_error table tbody").innerHTML += `
                <tr>
                    <td>#${id}</td>
                    <td title="${status_code}">${msg}</td>
                </tr>
                `
                })
        } else {
            alert('There is no image to post')

            e.currentTarget.classList.remove('disabled')
        }
    })

    /**
     * Posting all stores image
     */
    $('#post_captions_all').click((e) => {      // Post all stores image
        e.currentTarget.classList.add('disabled')
        let ids = []
        let cap_folds = $(`.caption_fold_`)
        for (let i = 0; i < cap_folds.length; i++) {
            let ele = cap_folds[i].querySelector('.post_allowed textarea.image_caption:nth-child(1)')
            if (ele) {
                ids.push(ele.dataset.id)
            }
        }

        if ($('.post_images_cur_fol.disabled').length) {     // Posting Not Allowed
            alert("please wait for other posting to get completed.")
            e.currentTarget.classList.remove('disabled')
        }
        else {       // Posting Allowed
            if (ids) {
                console.log(ids);
                $.post("/post_all", { ids: JSON.stringify(ids) })
                    .done((data) => {
                        for (let id in data) {
                            let ele_root = document.querySelector(`#fol_img_id_${id}`)
                            let ele = ele_root.parentElement.parentElement.parentElement.parentElement
                            let ststus = ele.querySelector('.Completed_post_image_count')
                            if (data[id][1] >= 200 && data[id][1] <= 300) {      // image posted successfully done
                                // delete the html element to show the images is posted and update the staus
                                // Update the post image count status
                                ststus.innerText = parseInt(ststus.innerText) + 1

                                // deleting the posted iage
                                ele_root.remove()
                            } else {      // error while posting the image on google
                                dd = data[id][0]
                                let error_count = ele.querySelector(".Failed_post_image_count")

                                // Display error message btn
                                error_count.parentElement.classList.remove("d-none")

                                // Updating Error Count
                                error_count.innerText = parseInt(error_count.innerText) + 1

                                // adding error message in dropdown table
                                ele.querySelector(".Failed_post_image_error table tbody").innerHTML += `
                                <tr>
                                    <td>#${id}</td>
                                    <td title="${dd.error.code}">${dd.error.message}</td>
                                </tr>
                                `
                            }


                        }
                        e.currentTarget.classList.remove('disabled')
                    })
                    .fail((jqXHR) => {
                        console.log(jqXHR)
                        e.currentTarget.classList.remove('disabled')
                    })
            }
            else {
                console.log("No image to post");
                alert('There is no image to post')
                e.currentTarget.classList.remove('disabled')
            }
        }
    })


    /**
     * Display the folder list of the stores.
     */
    $('#create_load_folder').click((e) => {
        e.currentTarget.classList.add('disabled')
        $.post("/folders")
            .done((data) => {
                table_html = `<table class="table table-hover">`
                for (let fold of data) {
                    table_html += `<tr><td>${fold}</td></tr>`
                }
                table_html += `</table>`
                $('#create_load_folder_body').html(table_html)
                e.currentTarget.classList.remove('disabled')
            })
            .fail((jqXHR) => {
                console.log(jqXHR)
                e.currentTarget.classList.remove('disabled')
            })
    })


})
