from os import getenv as os_getenv
from pathlib import Path
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import config as Config


FOLD_PATH = Path(os_getenv('AUTO_POST_FOLD_PATH', "/home/luffy/Pictures/AUTO_POST_FOLD_PATH"))

BASE_PATH = Path(__file__).resolve().parent

# db = SQLAlchemy()

def create_app(config=None):
    app = Flask(__name__)
    if not isinstance(config, str):
        config = os_getenv('FLASK_CONFIG', 'default')
        
    app.config.from_object(obj = Config[config])

    from .routes import gmb, gdrive

    app.register_blueprint(gmb.route)
    app.register_blueprint(gdrive.route)
    
    
    # app.config['SQLALCHEMY_BINDS'] = {
    #     'server_billing': os_getenv('server_billing_db')
    # }

    # # App Initialization
    # db.init_app(app)
    # from .models import StoreFolder, ImgCaption, Billing

    return app