from sqlalchemy import Column, String, Integer, Boolean, ForeignKey, Date
from sqlalchemy.orm import relationship

from app import db

BASE = db.Model


class StoreFolder(BASE):
    __tablename__ = 'storage_folder'
    
    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    fold_path = Column(String, unique=True, nullable=False)
    caption = Column(String(500), doc="Default Caption of the client.")
    dt = Column(Date, nullable=True, doc="store last post date.")
    acc_id = Column(String, doc="Account Id", nullable=False)
    loc_id = Column(String, doc="Location Id", nullable=False)
    name = Column(String, nullable=False, doc="Folder Name")   # File Name
    posts = Column(Integer, nullable=True, doc="Today Total posts count")
    cap = relationship('ImgCaption', backref='cap')

    def __repr__(self):
        return f"<StoreFolder(id={self.id}, fold_path='{self.fold_path}', caption='{self.caption}', dt={self.dt}, posts={self.posts})>"


class ImgCaption(BASE):
    __tablename__ = 'img_caption'
    
    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False)
    fold_id = Column(Integer, ForeignKey('storage_folder.id'), nullable=False)
    file_id = Column(String, unique=True, nullable=False)        # StoreFolder.id+ "..." + self.name
    name = Column(String, nullable=False, doc="File Name")   # File Name
    caption = Column(String(1000))
    post_id = Column(String, doc="Post Id")
    post_link = Column(String, doc="Link of the post")
    post_img_link = Column(String, doc="Post image Link")

    def __repr__(self):
        return f"<ImgCaption(id={self.id}, name='{self.name}', caption='{self.caption}')>"


class Billing(BASE):
    __bind_key__ = 'server_billing'
    __tablename__ = "billing"
    store_code = db.Column(String, primary_key=True)
    subscription_start = Column(Date, doc="subscription start date.")
    subscription_end = Column(Date, doc="subscription end date.")
    status = Column(String)
    folder_name = Column(String, doc="name of the folder")
    
    def __repr__(self):
        return f'<User store_code={self.store_code}, status={self.status}>'
    