#!/usr/bin/env python
# coding: utf-8




import random
from textblob import TextBlob

positive=['Thank you for your review,We\'re delighted to hear this response and we will be happy to serve you again.',
          
'Thank you for your review,We were happy to help you and get what you wanted. Hope to see you again.',
          "Thank you so much for this review. We really appreciate you being a customer. We’re here for you anytime.",
         
          "We are grateful that you took the time out to leave us a review.",
          "Thanks so much for sharing your experience with us.",
        "This review made our day!","Thank you for the great review! ","Thanks, We’re thrilled that you were satisfied with our services. Your feedback is appreciated, and we hope to be of help again soon!",

"Dear Customer , thank you for your review! We’re glad we made your experience with us a great one and will be happy to help you again soon."]
Negative=['Thank you for your feedback,We\'re sorry that we didnt meet your expectations. Our team will get in touch with you to resolve the issue.',

'Thank you for your feedback, We\'re sorry that you were disappointed, if there’s anything else we can do for you, please let us know!',

'Thank you for your feedback,We\'d like to appologize for the inconvenience casued, we hope we can use this to improve in future.'
"Thank you for providing your feedback and letting us know about  this issue.",
"We apologize that our service did not satisfy your expectations.",
"Thank you for your review, all feedback is important to us and we’re sorry to hear you’ve had such a frustrating experience.",
"Thanks so much for bringing this issue to our attention and please let me apologize for the issue.",
"We would like to apologize for your recent experience. We're sorry to hear you were less than satisfied.",
"We’re sorry to hear of your less-than-satisfactory experience with us and hope you will accept our sincerest apologies."]



five=["Thank you for the 5 star rating.",

"Thank you so much for taking the time to leave us a 5 star rating - it's much appreciated!",

"Thank you so much for taking the time to leave us a 5-star review."]


three_four=[" Thanks for sharing your rating with us and the community.",
       'We are grateful that you took the time out to leave us a review. Your feedback helps us to improve service for everyone',
      "We really appreciate you taking the time to share your rating with us. We look forward to seeing you again soon.",
      "Thank you so much for taking the time to leave us a rating."
]

one_two=[
'Thank you for your feedback, We\'re sorry that you were disappointed, if there’s anything else we can do for you, please let us know!',

'Thank you for your feedback,We\'d like to appologize for the inconvenience casued, we hope we can use this to improve in future.']



def Sentiment_analysis(txt):
    
    blob1=TextBlob(txt.lower())
    
    k=blob1.sentiment
    if k[0] >0.1:

        return random.choice(positive)


    elif k[0] ==0.0:
        

        return "Thanks for your Feedback."
    else:

        return random.choice(Negative)
    
