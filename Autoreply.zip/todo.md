http://localhost:5000/gmb/review
http://localhost:2001/gmb/loc/locs


# Post All 
post only one image of all the folders 
if image already posted than don't post it


- image:
    - store logo on top right corner
    - "wifr" text in bottom right corner
