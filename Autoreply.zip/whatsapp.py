from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

# Replace 'Your Message' with the message you want to broadcast
message = "Your Message"

# Replace with the contact names or phone numbers you want to send the message to
contacts = ["Contact1", "Contact2", "Contact3"]

# Set the path to your ChromeDriver executable
chrome_driver_path = "path/to/chromedriver"

# Initialize Chrome WebDriver
driver = webdriver.Chrome(executable_path=chrome_driver_path)

# Open WhatsApp Web
driver.get("https://web.whatsapp.com/")
time.sleep(10)  # Allow time to scan the QR code manually

# Iterate through the list of contacts and send the message
for contact in contacts:
    search_box = driver.find_element("xpath", '//div[@contenteditable="true"]')
    search_box.send_keys(contact)
    time.sleep(2)
    search_box.send_keys(Keys.RETURN)
    time.sleep(2)

    message_box = driver.find_element("xpath", '//div[@contenteditable="true"][@data-tab="1"]')
    message_box.send_keys(message)
    message_box.send_keys(Keys.RETURN)
    time.sleep(2)

# Close the browser after sending messages
driver.quit()