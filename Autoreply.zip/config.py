from os import (
    getenv as os_getenv, 
    environ as os_environ, 
    makedirs as os_makedirs
)
from pathlib import Path

SQLALCHEMY_DATABASE_URI = 'sqlite:///db.sqlite3'
SQLALCHEMY_BINDS = {
    'server_billing': os_getenv('server_billing_db')
}

ROOT_PATH = Path(__file__).resolve().parent      #  ROOT_PATH: ./Chat/src


class BasicConfig():
    """ Basic app config for all enviroment """
    
    # Flask Enviroment
    SECRET_KEY = os_getenv('SECRET_KEY', 'dev')
    AUTOREVIEW_STORE_JSON = os_getenv("AUTOREVIEW_STORE_JSON", ROOT_PATH / '.res' / 'autoreview_store.json')

    
    # Email
    MAIL_SERVER = os_getenv('MAIL_SERVER', 'smtp.gmail.com')        # default: Google mail
    MAIL_PORT = int(os_getenv('MAIL_PORT', '587'))
    MAIL_USE_TLS = os_getenv('MAIL_USE_TLS', 'true').lower() in ['true', 'on', '1']
    MAIL_USERNAME = os_getenv('MAIL_USERNAME')
    MAIL_PASSWORD = os_getenv('MAIL_PASSWORD')
    WIFR_MAIL_SUBJECT_PREFIX = '[WIFR]'
    WIFR_MAIL_SENDER = 'WIFR Admin <whatifretalytics@gmail.com>'

    def __init__(self):
        assert os_getenv('SERVICE_ACCOUNT_FILE'), 'SERVICE_ACCOUNT_FILE IS NOT SET!'


class DevConfig(BasicConfig):
    ENV="development"
    DEBUG=True
    
    SQLALCHEMY_DATABASE_URI = os_getenv(
        'DEV_DATABASE_URI',
        'sqlite:///' + str(ROOT_PATH / 'dev.sqlite3')
    )

    # logging path
    LOG_DIR = Path( 
        os_getenv('USER_LOG_PATH', str(ROOT_PATH / 'Logs')) 
    ) / 'dev'

    try:
        os_makedirs(LOG_DIR)
    except Exception as e:
        pass

    @classmethod
    def init_app(cls, app):
        cls.__init__(cls)
        os_environ['LOG_DIR'] = str(cls.LOG_DIR)
        print('THIS APP IS IN DEBUG MODE.')


class TestConfig(BasicConfig):
    TESTING = True

    ENV="development"
    DEBUG=True
    
    SQLALCHEMY_DATABASE_URI = os_getenv(
        'DEV_DATABASE_URI',
        'sqlite:///' + str(ROOT_PATH / 'test.sqlite3')
    )
    SQLALCHEMY_ECHO=False

    # Flask_WTF
    WTF_CSRF_ENABLED = False

    # logging path
    LOG_DIR = Path( 
        os_getenv('USER_LOG_PATH', str(ROOT_PATH / 'Logs')) 
    ) / 'test'
        
    try:
        os_makedirs(LOG_DIR)
    except Exception as e:
        pass

    @classmethod
    def init_app(cls, app):
        cls.__init__(cls)
        os_environ['LOG_DIR'] = str(cls.LOG_DIR)


class ProConfig(BasicConfig):
    DEBUG = False
    PORT = 9002
    HOST = '0.0.0.0'
    ENV = "production"
    
    SQLALCHEMY_DATABASE_URI = os_getenv(
        'DATABASE_URI',
        'sqlite:///' + str(ROOT_PATH / 'db.sqlite3')
    )
    SQLALCHEMY_ECHO=False

    # logging path
    LOG_DIR = Path( 
        os_getenv('USER_LOG_PATH', str(ROOT_PATH / 'Logs')) 
    ) / 'prod'
    
    try:
        os_makedirs(LOG_DIR)
    except Exception as e:
        pass

    @classmethod
    def init_app(cls, app):
        cls.__init__(cls)
        os_environ['LOG_DIR'] = str(cls.LOG_DIR)


config = {
    'development': DevConfig,
    'testing': TestConfig,
    'production': ProConfig,
    'default': DevConfig
}
