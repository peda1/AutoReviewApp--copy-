# Deployment Command 
```sh
# workoer count = (2* no of cors) + 1  
# Get the no of cores == $ nproc --all
gunicorn -w 5 app:app
```
# For test Link 
http://127.0.0.1:5000/gmb/loc/accs
http://127.0.0.1:5000/gmb/review


[Python Flask Tutorial: Deploying Your Application (Option #1) - Deploy to a Linux Server](https://www.youtube.com/watch?v=goToXTC96Co)

# Server Setup From Basic
1.
```sh
sudo ufw default allow outgoing
sudo ufw default deny incoming
sudo ufw allow ssh
```

/etc/nginx/site-enabled/flask_auto_review
```nginx
server {
    listen 80;
    server_name 0.0.0.0;

    location /static {
        alias /home/luffy/dev/office/AutoReviewApp/app/static;
    }

    location / {
        proxy_pass http://localhost:2001
        include /etc/nginx/proxy_params;
        proxy_redirect off;
    }
}


server {
    listen 80;
    server_name YOUR_IP_OR_DOMAIN;

    location /static {
        alias /home/YOUR_USER/YOUR_PROJECT/flaskblog/static;
    }

    location / {
        proxy_pass http://localhost:8000;
        include /etc/nginx/proxy_params;
        proxy_redirect off;
    }
}
```

# Allow HTTP/TCP trafic
```sh
sudo ufw allow http/tcp
```

# enable the ufw 
```sh
sudo ufw enable
```
    
