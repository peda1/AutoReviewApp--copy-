

## Production Setup
for Production documentation pls refer [this](./prod/README.md)




Service File: /etc/systemd/system/AutoReviewApp.service

nohup /home/server/.virtualenvs/AutoReviewApp-fd65n_JR/bin/gunicorn --workers 4 --bind localhost:2001 wsgi:app &


/home/server/.virtualenvs/AutoReviewApp-fd65n_JR/bin/python /home/server/.dev/AutoReviewApp/wsgi.py