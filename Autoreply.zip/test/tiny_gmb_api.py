""" Google My Business api """

from asyncio import exceptions
import os
import json
import datetime
from pathlib import Path
from shutil import move as shutil_move
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

import requests
from requests.api import request

# from tiny_drop_box_create_link import create_url_if_local
from tiny_gdrive_create_link import get_link as create_url_if_local


CLIENT_ID = "777306933000-9dc9hid3i5vth30b5ip4ud344fhmtpji.apps.googleusercontent.com"      # Read From client_secret.json
CLIENT_SECRET = "-FFLI43Wbd-8GJjW4ogECClQ"  # Read from a file or environmental variable in a real app
SCOPE = 'https://www.googleapis.com/auth/business.manage'                   # Read From client_secret.json
REDIRECT_URI = 'http://localhost:5000/oauth2callback'
BASE_URL = 'https://mybusiness.googleapis.com/v4/'
BASE_PATH = os.path.dirname(os.path.abspath(__file__))
ARCHIVE_PATH = Path().home() / '.Post_Archive'

try:os.makedirs(str(ARCHIVE_PATH))
except Exception as e : pass

class TokenCode:
    """ Getting tokenCode to """

    def __init__(self):
        self.token_path = os.path.join(BASE_PATH, 'conf', 'ref_token.json')
    
    def get_access_token(self):
        """ getting access_token """
        with open (self.token_path) as token_f:
            acc_token = json.load(token_f)
            if self.is_access_token_expired(acc_token.get("new_token_time")):
                return self.get_new_access_token(acc_token.get("refresh_token"))
            else:
                return acc_token.get("access_token")

    def get_new_access_token(self, refresh_token):
        """ Getting New **access_token** Using **refresh_token** """

        url = "https://oauth2.googleapis.com/token"             # Read From client_secret.json
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = {
            "client_id": CLIENT_ID,                             # Read From client_secret.json
            "client_secret": CLIENT_SECRET,                     # Read From client_secret.json
            "refresh_token": refresh_token,
            "grant_type": "refresh_token"
        }
        req = requests.post(url, headers=headers, data=data)

        # refresh_token Error 
            # {
            #     "error": "invalid_grant",
            #     "error_description": "Bad Request"
            # }
        # CLIENT_ID Error 
            # {
            #     "error": "invalid_client",
            #     "error_description": "The OAuth client was not found."
            # }
        # CLIENT_SECRET Error 
            # {
            #     "error": "invalid_client",
            #     "error_description": "Unauthorized"
            # }
        # print(req.text)
        # Updating Access Token
        new_token_time = datetime.datetime.now() + datetime.timedelta(seconds=int(req.json().get("expires_in"))-99 )
        self.update_access_token(req.json().get("access_token"), new_token_time)
        return req.json().get("access_token")

    def is_access_token_expired(self, token_exp_time):
        """ Checking is access_token expired or not """
        if datetime.datetime.strptime(token_exp_time, "%Y-%m-%d %H:%M:%S.%f") > datetime.datetime.now():
            # Token Not Is Expire
            return False 
        else:
            # Token Is Expire
            return True

    def update_access_token(self, access_token, new_token_time):
        """ Updating the new access_token and  new_token_time """
        with open (self.token_path) as token_f:
            acc_token = json.load(token_f)
            acc_token['access_token'] = access_token
            acc_token['new_token_time'] = str(new_token_time)
            json.dump(acc_token, open(self.token_path, "w"), indent=4)


class AccLocId(TokenCode):
    """ Getting token And id i.e account_id, location_id, post_id, etc. """
    def __init__(self):
        super(AccLocId, self).__init__()
        self.acc_url_ = "https://mybusinessaccountmanagement.googleapis.com/v1/"
        self.loc_url_ = "https://mybusinessbusinessinformation.googleapis.com/v1/"
    
    def get_store_labels(self):
        """ 
        Getting **storeCode** and **labels** for getting acc_id and loc_id from GMB 

        # calling the get_loc_id() method from here and set the scheduler in Do_Action class
        """

    def get_acc_id(self):
        """ Getting Account Id """
        # O/P 
            # {
            #     "accounts": [
            #         {
            #             "name": "accounts/{accountId}",
            #             "accountName": "What If",
            #             "type": "PERSONAL",
            #             .......
            #             "profilePhotoUrl": "//lh4.googleusercontent.com/********************/photo.jpg"
            #         }},
            #         {
            #             "name": "accounts/{accountId}",
            #             "accountName": "WIFR Location Group",
            #             "type": "LOCATION_GROUP",
            #             "role": "OWNER",13702357773896161830
            #             .......
            #             "accountNumber": "{accountNumber}",
            #             "permissionLevel": "OWNER_LEVEL"
            #         }
            #     ]
            # }
        url=self.acc_url_+"accounts"

        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        req = requests.get(url, headers=headers)

        # Check for the error before return 
            # {
            #     "error": {
            #         "code": 404, 
            #         "message": "Requested entity was not found.", 
            #         "status": "NOT_FOUND"
            #     }
            # }
        return req.json()
    
    def get_loc_id(self, locId, storeCode=None, labels=None):
        """ Geting Location Id 
        
        check location id is present or not 
        if present return image folder name     FOLDER_NAME_FORMATE : <loc_id>___<loc_name>
        """
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }

        # acc_url = self.get_acc_id().get("accounts")[0].get("name")
        # url = BASE_URL+acc_url+"/locations"
        # headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
        # req = requests.get(url, headers=headers)
        # is_location_found = False
        # for i in req.json().get("locations"):
        #     # if i.get('name').split('/')[-1] == locId or str(i.get("storeCode")) == str(storeCode):
        #     # print(i['name'])

        #     if i.get('name').split('/')[-1] == locId:
        #         # print(json.dumps(i))
        #         client_folder_name = f"{i.get('name').split('/')[-1]}___{i.get('locationName')}"
        #         is_location_found = {'locName':i.get("name"), 'clientFolderName':client_folder_name}
        #         break
        # if is_location_found:
        #     return is_location_found
        # else:
        #     return "No Loction Found!"
        

        locs = self.get_locations()
        is_location_found = False
        try:
            for i in locs.get("locations"):
                if i.get('name').split('/')[-1] == locId:
                    # print(json.dumps(i))
                    client_folder_name = f"{i.get('name').split('/')[-1]}___{i.get('title')}"
                    is_location_found = {'locName':i.get("name"), 'clientFolderName':client_folder_name}
                    break
            if is_location_found:
                # print(f"is_location_found : {is_location_found}")
                return is_location_found
            else:           # No Loction Found
                return False
        except Exception as e:      # No Loction Found
            # print(e)
            return False

    # def get_loc_id(self, storeCode, labels=None):
    def old_get_locations(self, acc_id=None):
        """ Geting Location Id """
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "locationName": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }
        if acc_id:
            acc_urls = (f"accounts/{acc_id}",)
        else:
            acc_urls = [acc.get("name") for acc in self.get_acc_id().get("accounts")]
        
        all_locs = {'locations': []}
        for acc_url in acc_urls:
            # print(f"\n\n\nacc_url :\t {acc_url} ")
            url = self.loc_url_+acc_url+"/locations?readMask=title,name,storeCode"

            headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
            resp = requests.get(url, headers=headers)
            try:
                if resp.status_code == 200:
                    # return { "code": resp.status_code, "status": resp.reason, "data":resp.json() }

                    loc_data = resp.json()
                    if loc_data:
                        for j in loc_data['locations']:
                            j['name'] =  acc_url +"/"+ j['name']
                            # print(j)
                            all_locs['locations'].append(j)
            except Exception as e:
                print('\n\n\n\n\n', '*'*70)
                print(e)
                # print(resp)
                print('*'*70, '\n\n\n\n\n')
                pass


        return all_locs

    def get_loc_by_store_code(self, storeCode):
        """ 
        Getting the location with help of Store Code or loc_id
        
        :param storeCode: Store Code Of Store
        :type storeCode: str
        """

        loc_list = self.get_locations()
        # print(f"\n\n{json.dumps(loc_list)}\n\n")
        
        if storeCode:
            for loc in loc_list.get("locations"):
                if loc.get('storeCode'):
                    if storeCode == loc.get('storeCode'):
                        return loc
            return {
                "error": {
                    "code" : 400,
                    "status" : "INVALID_ARGUMENT",
                    "message" : "Invalid location argument."
                }
            }
        else:
            return {
                "error": {
                    "code" : 404,
                    "status" : "NOT_FOUND",
                    "message" : "Store code not found"
                }
            }

    def get_loc_by_name(self, name):
        """ Geting Location Id 
        
        check location id is present or not 
        if present return image folder name     FOLDER_NAME_FORMATE : <loc_id>___<loc_name>
        """
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }
        locs = self.get_locations()
        is_location_found = False
        try:
            for i in locs.get("locations"):
                if i.get('name').split('/')[-1] == name:
                    # print(json.dumps(i))
                    client_folder_name = f"{i.get('name').split('/')[-1]}___{i.get('title')}"
                    is_location_found = {'locName':i.get("name"), 'clientFolderName':client_folder_name}
                    break
            if is_location_found:
                print(f"is_location_found : {is_location_found}")
                return is_location_found
            else:           # No Loction Found
                return False
        except Exception as e:      # No Loction Found
            print(e)
            return False

    def get_locations(self, acc_id=None):
        """ Geting Location Id """
        # O/P 
            # {
            #     "locations": [
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "Test Business",
            #             ...
            #         },
            #         {
            #             "name": "accounts/{accountId}/locations/{locationId}",
            #             "title": "2nd Test Business",
            #             ...
            #         }
            #     ]
            # }
        if acc_id:
            acc_urls = (f"accounts/{acc_id}",)
        else:
            acc_urls = [acc.get("name") for acc in self.get_acc_id().get("accounts")]
        all_locs = {'locations': []}
        for _acc in acc_urls:
            # print(_acc.split('/')[-1], end='')
            # print(": \n\t",self.get_loc(_acc.split('/')[-1], pageSize=100)['locations'])
            try:
                _tmp_loc = self.get_loc(_acc.split('/')[-1], pageSize=100)['locations'] if self.get_loc(_acc.split('/')[-1], pageSize=100)['locations'] else list()
                all_locs['locations'] +=  _tmp_loc
            except Exception as e:
                logger.exception(f"Adding Location of Account id: {_acc}")
                # print(e, f"Account id: {_acc}")
        return all_locs

    def get_loc(self, acc_id:str, pageSize:int=25, pageToken:str=None, filter:str=None, orderBy:str=None, readMask:str=None, _loc_list:list=[]):
        page_size = pageSize if pageSize >= 1 and pageSize <= 100 else 25
        page_toke = f"&pageToken={pageToken}" if pageToken else ""
        url = self.loc_url_+f"accounts/{acc_id}/locations?pageSize={page_size}{page_toke}&readMask=title,name,storeCode"
        
        headers = {"Authorization": "Bearer {}".format(self.get_access_token()), "Content-Type": "application/json; charset=UTF-8"}
        resp = requests.get(url, headers=headers)
        
        if _loc_list:
            _locs = {'locations': _loc_list}
        else:
            _locs = {'locations': list()}
        
        if resp.status_code == 200:
            loc_data = resp.json()
            
            if loc_data:
                for j in loc_data['locations']:
                    j['name'] =  f"accounts/{acc_id}/"+ j['name']
                    _locs['locations'].append(j)
            if loc_data.get('nextPageToken'):
                return self.get_loc(
                        acc_id,
                        pageToken=loc_data.get('nextPageToken'),
                        _loc_list = _locs['locations']
                    )
            else:
                # Returning all locations of this group
                return _locs


class Posts(AccLocId):
    """All the Posts Features"""
    def __init__(self):
        AccLocId.__init__(self)

    def get_posts(self):
        """ Get all the Posts done previously """

    def create_event_post(self, data, storeCode, labels=None):
        """ Creates a Event Post """
        url = BASE_URL+str(self.get_loc_id(storeCode, labels))+"/localPosts"
        c_dt = datetime.datetime.now() + datetime.timedelta(minutes=2)
        
        # Formating Data in 
        frmt_data = {} 
        frmt_data["languageCode"] = "en-US"
        frmt_data["summary"] = data.get("summary")
        frmt_data_event_schedule_startDate = {
            "year" : int(data.get("startDate (year)")),
            "month" : int(data.get("startDate (month)")),
            "day" : int(data.get("startDate (day)"))}
        frmt_data_event_schedule_startTime = {
            "hours": int(data.get("startTime (hours)") if data.get("startTime (hours)") else c_dt.hour),
            "minutes": int(data.get("startTime (minute)") if data.get("startTime (minute)") else c_dt.minute),
            "seconds": int(data.get("startTime (sec)") if data.get("startTime (sec)") else 0),
            "nanos": int(data.get("startTime (nanoSec)") if data.get("startTime (nanoSec)") else 0)}
        frmt_data_event_schedule_endDate = {
            "year" : int(data.get("endDate (year)")),
            "month" : int(data.get("endDate (month)")),
            "day" : int(data.get("endDate (day)"))}
        frmt_data_event_schedule_endTime = {
            "hours": int(data.get("endTime (hours)") if data.get("endTime (hours)") else 23),
            "minutes": int(data.get("endTime (minute)") if data.get("endTime (minute)") else 59),
            "seconds": int(data.get("endTime (sec)") if data.get("endTime (sec)") else 0),
            "nanos": int(data.get("endTime (nanoSec)") if data.get("endTime (nanoSec)") else 0)}
        frmt_data_event_schedule = {
            "startDate" : frmt_data_event_schedule_startDate,
            "startTime" : frmt_data_event_schedule_startTime,
            "endDate" : frmt_data_event_schedule_endDate,
            "endTime" : frmt_data_event_schedule_endTime}
        frmt_data["event"] = {
            "title" : data.get("title"),
            "schedule" : frmt_data_event_schedule}
        frmt_data["media"] = [
            {
                "mediaFormat" : "PHOTO",
                "sourceUrl" : create_url_if_local(i.replace(" ","").replace("\t", ""))
            }for i in data.get("media PHOTO(url/path)").split(',') if i != ""] \
                + [{
                    "mediaFormat" : "VIDEO",
                    "sourceUrl" : create_url_if_local(i.replace(" ","").replace("\t", ""))
                }for i in data.get("media VIDEO(url/path)").split(',') if i != ""]
        
        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        headers['Content-Length'] = str(len(json.dumps(frmt_data)))
        req = requests.post(url, headers=headers, data=json.dumps(frmt_data))
        # print(json.dumps(req.json(), indent=4))
        return req

    def create_action_post(self, id, summary, img, opFolderOfR, storeCode=None, labels=None):
        """ Creates a Action Post (UI/UX -> What's New) """
        print(f"\n\n\n{'*'*50}\n{id} \t:-  {summary}, {img} \n{'*'*50} \n")
        loc = self.get_loc_id(id, storeCode, labels)
        if loc == False:
            return "Location Not Found!", 404
        # print(loc, end='\n\n\n\n')
        imgList = []
        for i in img.split(','):
            is_img = opFolderOfR / loc.get('clientFolderName') / i.strip()
            if not (is_img.exists()):
                return f"File Not Found! : {i}."
            else:
                imgList.append(is_img)
        url = BASE_URL+str(loc.get('locName'))+"/localPosts"
        c_dt = datetime.datetime.now() + datetime.timedelta(minutes=2)
        # Formating Data in 
        frmt_data = {} 
        frmt_data["languageCode"] = "en-US"
        frmt_data["summary"] = summary
        frmt_data["callToAction"] = {
            "actionType" : 'CALL',
            "url" : None}
        frmt_data["media"] = [
            {
                "mediaFormat" : "PHOTO",
                "sourceUrl" : create_url_if_local(i.strip(), opFolderOfR / loc.get('clientFolderName'))
            }for i in img.split(',') if i != ""]
        frmt_data['topic_type'] = "STANDARD"

        headers = {'Authorization': 'Bearer {}'.format(self.get_access_token())}
        headers['Content-Type'] = 'application/json; charset=UTF-8'
        headers['Content-Length'] = str(len(json.dumps(frmt_data)))
        print(json.dumps(frmt_data, indent=4))
        upload_media(str(loc.get('locName')), headers, frmt_data['media'])
        req = requests.post(url, headers=headers, data=json.dumps(frmt_data))
        try:
            if req.status_code == 200 :
                # delete the image which are posted
                file_name = f"{datetime.datetime.now().strftime('%y_%m_%d %H_%M_%S_%f')}{Path(i).suffix}"
                arch_folder_path = ARCHIVE_PATH / req.url.split('/')[-2]
                # Creatimg location Archive folder 
                try:os.makedirs(str(arch_folder_path))
                except Exception as e : pass



                try: 
                    for i in imgList:
                        shutil_move(i, str(ARCHIVE_PATH / arch_folder_path / file_name))
                        # os.remove(i)
                except FileNotFoundError:
                    pass
                except Exception as e:
                    print(e)
                try:
                    # Writing Summary in file
                    summary_file_name = Path(file_name).stem + ".txt"
                    summary_file_path = arch_folder_path/summary_file_name
                    write_summary(summary_file_path, summary)
                except Exception as e:
                    print("Write Summary error: ", e)
                return req
            else:
                print(json.dumps(req.json(), indent=3))
                # delete the image which are posted
                file_name = f"{datetime.datetime.now().strftime('%y_%m_%d %H_%M_%S_%f')}{Path(i).suffix}"
                arch_folder_path = ARCHIVE_PATH / req.url.split('/')[-2] / '.error'
                
                # Creatimg location Archive folder 
                try:os.makedirs(str(arch_folder_path))
                except Exception as e : pass

                
                

                try: 
                    for i in imgList:
                        shutil_move(i, str(ARCHIVE_PATH / arch_folder_path / file_name))
                        # os.remove(i)
                except FileNotFoundError:
                    pass
                except Exception as e:
                    print(e)
                try:
                    # Writing Summary in file
                    summary_file_name = Path(file_name).stem + ".txt"
                    summary_file_path = arch_folder_path/summary_file_name
                    write_summary(summary_file_path, summary)
                except Exception as e:
                    print("Write Summary error: ", e)
                return req
        except Exception as e:
            print('\n\n\n\n\n', '*'*70)
            print(e)
            # print(req)
            print('*'*70, '\n\n\n\n\n')
            
    def create_offer_post(self):
        """ Creates a Offer Post """
        return
    
    def edit_post(self):
        """ Edits the older Post """
        return

    def delete_post(self):
        """ Delete The Posts """
        return


def upload_media(loc, header, data):
    url = BASE_URL+loc+"/media"
    # {
    # "mediaFormat": "PHOTO",
    # "locationAssociation": {
    #     "category": "COVER"
    # },
    # "sourceUrl": "",
    # }
    for i in data:
        frmt_data = {
            "mediaFormat": "PHOTO",
            "locationAssociation": {
                "category": "ADDITIONAL"
            },
            "sourceUrl": i.get('sourceUrl'),
        }
        try:
            header['Content-Length'] = str(len(json.dumps(frmt_data)))
            req = requests.post(url, headers=header, data=json.dumps(frmt_data))
            # print('*'*50)
            # print(url,"\n",  header,"\n", json.dumps(frmt_data), "\n\n\n")
            # print(req.text)
            # print(req.json)
            # print('*'*50)
        except Exception as e:
            print('\n\n\n\n\n','*'*50)
            print("Media Upload Error GMB", e)
            print(url,"\n", json.dumps(frmt_data), "\n\n\n")
            print('*'*50, '\n\n\n\n\n')


def write_summary(summary_file_name, summary):
    try:
        with open(str(ARCHIVE_PATH/summary_file_name), 'w') as _file:
            _file.write(summary)
    except Exception as e:
        print('Faild to write a summary file')
        return False
    else: return True

if __name__ == "__main__":
    pass
    # import json
    # print("Hello")
    # acc_loc = AccLocId().get_acc_id()
    # print(json.dumps(acc_loc, indent=4))
    # print("world")
    # from pathlib import Path
    # post = Posts().create_action_post(
    #     "14270024494954641074", 
    #     "autopost test", 
    #     "car.jpg", 
    #     Path("/home/server/Desktop/services/G-Buz/"))
    # print(post) 
    # acc_id = "104934047574207510837"      $ Trainings
    # loc_id = "14270024494954641074"       # Pedagogy
    # print(AccLocId().get_loc(acc_id))
    

    # opFolderOfR = Path('').home() / 'services' / 'G-Buz'    # default path
    